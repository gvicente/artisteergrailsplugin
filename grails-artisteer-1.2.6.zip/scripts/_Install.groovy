
ant.mkdir(dir: "${basedir}/grails-app/artisteer")
ant.mkdir(dir: "${basedir}/grails-app/artisteer/zip")
ant.mkdir(dir: "${basedir}/grails-app/artisteer/.target")

println "[ARTISTEER PLUGIN - INSTALL PROCESS] Created Directories"